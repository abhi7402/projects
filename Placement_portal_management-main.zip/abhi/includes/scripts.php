<!-- Custom JS -->
<script src="assets/js/app.js"></script>

<!-- Bootstrap Core JS -->
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>


<!-- charts -->
<script src="assets/js/chart.js"></script>

<!-- data tables -->
<script src="assets/js/dataTables.bootstrap4.min.js"></script>
<script src="assets/js/jquery.dataTables.min.js"></script>

<!-- drop files -->
<script src="assets/js/dropfiles.js"></script>

<!-- calendar starts here -->
<script src="assets/js/fullcalendar.min.js"></script>
<script src="assets/js/jquery.fullcalendar.js"></script>

<!-- jquery maskedinput -->
<script src="assets/js/jquery.maskedinput.min.js"></script>

<!-- jquery slimscroll -->
<script src="assets/js/jquery.slimscroll.min.js"></script>
<!-- jquery touch punch -->
<script src="assets/js/jquery.ui.touch-punch.min.js"></script>

<!-- jquery  main-->
<script src="assets/js/jquery-3.2.1.min.js"></script>
<!-- jquery ui -->
<script src="assets/js/jquery-ui.min.js"></script>

<!-- mask -->
<script src="assets/js/mask.js"></script>

<!-- moment js -->
<script src="assets/js/moment.min.js"></script>

<!-- multi select  -->
<script src="assets/js/multiselect.min.js"></script>
<!-- Select2 JS -->
<script src="assets/js/select2.min.js"></script>

<!-- popper js  -->
<script src="assets/js/popper.min.js"></script>

<!-- task js -->
<script src="assets/js/task/js"></script>




	





