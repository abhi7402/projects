<div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div class="sidebar-menu">
						<ul>
							<li> 
								<a href="index.php"><i class="la la-home"></i> <span>Back to Home</span></a>
							</li>
							<li class="menu-title">Settings</li>
							<li> 
								<a href="settings.php"><i class="la la-building"></i> <span>Company Settings</span></a>
							</li>
				
							<li> 
								<a href="theme-settings.php"><i class="la la-photo"></i> <span>Theme Settings</span></a>
							</li>
							<li> 
								<a href="roles-permissions.php"><i class="la la-key"></i> <span>Roles & Permissions</span></a>
							</li>
							<li> 
								<a href="roles-permissions.php"><i class="la la-key"></i> <span>Roles & Permissions</span></a>
							</li>
						
							<li> 
								<a href="invoice-settings.php"><i class="la la-pencil-square"></i> <span>Invoice Settings</span></a>
							</li>
							<li> 
								<a href="salary-settings.php"><i class="la la-money"></i> <span>Salary Settings</span></a>
							</li>
							
							<li> 
								<a href="change-password.php"><i class="la la-lock"></i> <span>Change Password</span></a>
							</li>
							<li> 
								<a href="leave-type.php"><i class="la la-cogs"></i> <span>Leave Type</span></a>
							</li>
						</ul>
					</div>
                </div>
            </div>