<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_info";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$hotel_name = $_POST["hotel_name"];
$hotel_phone = $_POST["hotel_phone"];
$hotel_city = $_POST["hotel_city"];
$hotel_review = $_POST["hotel_review"];
$hotel_special_dish = $_POST["hotel_special_dish"];
$hotel_food_type = $_POST["hotel_food_type"];

$sql = "INSERT INTO hotel_info (hotel_name, hotel_phone, hotel_city, hotel_review, hotel_special_dish, hotel_food_type)
VALUES ('$hotel_name', '$hotel_phone', '$hotel_city', '$hotel_review', '$hotel_special_dish', '$hotel_food_type')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
