<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_info";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT hotel_name, hotel_phone, hotel_city, hotel_review, hotel_special_dish, hotel_food_type FROM hotel_info LIMIT 5";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Hotel Name: " . $row["hotel_name"]. " - Phone: " . $row["hotel_phone"]. " - City: " . $row["hotel_city"]. " - Review: " . $row["hotel_review"]. " - Special Dish: " . $row["hotel_special_dish"]. " - Food Type: " . $row["hotel_food_type"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>
