<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "company";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $empid = mysqli_real_escape_string($conn, $_POST['empid']);
  $empname = mysqli_real_escape_string($conn, $_POST['empname']);
  $empqualification = mysqli_real_escape_string($conn, $_POST['empqualification']);
  $empsalary = mysqli_real_escape_string($conn, $_POST['empsalary']);
  $empdesignation = mysqli_real_escape_string($conn, $_POST['empdesignation']);
  $empaddress = mysqli_real_escape_string($conn, $_POST['empaddress']);

  $sql = "INSERT INTO employees (empid, empname, empqualification, empsalary, empdesignation, empaddress)
  VALUES ('$empid', '$empname', '$empqualification', '$empsalary', '$empdesignation', '$empaddress')";

  if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}

mysqli_close($conn);
?>
