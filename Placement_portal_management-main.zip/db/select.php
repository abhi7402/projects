<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "company";
  
  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  
  $sql = "SELECT empid, empname, empqual, empsal, empdesig, empaddress FROM employees";
  $result = $conn->query($sql);
  
  if ($result->num_rows > 0) {
    echo "<table><tr><th>Employee ID</th><th>Employee Name</th><th>Employee Qualification</th><th>Employee Salary</th><th>Employee Designation</th><th>Employee Address</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["empid"]. "</td><td>" . $row["empname"]. "</td><td>" . $row["empqual"]. "</td><td>" . $row["empsal"]. "</td><td>" . $row["empdesig"]. "</td><td>" . $row["empaddress"]. "</td></tr>";
    }
    echo "</table>";
  } else {
    echo "0 results";
  }
  
  $conn->close();
?>
